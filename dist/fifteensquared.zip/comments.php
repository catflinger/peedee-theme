<ol class="commentlist">
    <?php wp_list_comments(); ?>
</ol>
<?php comment_form(); ?>