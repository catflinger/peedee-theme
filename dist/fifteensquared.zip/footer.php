
            <div class="clearingdiv">&nbsp;</div>
            
        </div> <!-- end of the container, opened in header.php -->

        <!-- the footer -->
        <div id="footer">
            <a href="<?php echo esc_url( home_url() ); ?>/"><?php bloginfo('name'); ?></a> 
            is powered by 
            <a href="http://wordpress.org/">WordPress</a> | 
            Design by fifteensquared based on an origianl theme by
            <a href="http://andreasviklund.com">Andreas Viklund</a> 
        </div>
        
        <?php wp_footer(); ?>

    </body>
</html>
